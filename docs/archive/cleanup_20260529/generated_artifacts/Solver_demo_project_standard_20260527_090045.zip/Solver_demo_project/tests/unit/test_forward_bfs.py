"""Unit tests for the forward BFS planner core."""

from dataclasses import dataclass, field

from app.core.planner.bfs import BfsLimits, forward_bfs_plan


@dataclass
class MockPrecond:
    feature_key: str
    operator: str
    feature_value: str
    value_list: list | None = None


@dataclass
class MockEffect:
    feature_key: str
    new_value: str = ""
    effect_type: str = "set"
    delta_value: float | None = None


@dataclass
class MockRule:
    id: int
    code: str
    duration_min: int
    preconditions: list[MockPrecond] = field(default_factory=list)
    effects: list[MockEffect] = field(default_factory=list)


@dataclass
class MockFeatureDef:
    value_type: str


def test_forward_bfs_finds_multistep_precondition_chain():
    warmup = MockRule(
        id=1,
        code="OP_WARMUP",
        duration_min=10,
        effects=[MockEffect("temperature", "hot")],
    )
    calibrate = MockRule(
        id=2,
        code="OP_CALIBRATE",
        duration_min=5,
        preconditions=[MockPrecond("temperature", "eq", "hot")],
        effects=[MockEffect("calibration", "on")],
    )

    result = forward_bfs_plan(
        current_state={"temperature": "cold", "calibration": "off"},
        target_state={"temperature": "hot", "calibration": "on"},
        rules=[calibrate, warmup],
        feature_defs={},
    )

    assert result.status == "success"
    assert [step.rule.code for step in result.path] == ["OP_WARMUP", "OP_CALIBRATE"]


def test_forward_bfs_repeats_numeric_rule_instances():
    fill = MockRule(
        id=1,
        code="OP_FILL",
        duration_min=5,
        effects=[MockEffect("water_level", effect_type="increment", delta_value=20)],
    )

    result = forward_bfs_plan(
        current_state={"water_level": "0"},
        target_state={"water_level": "40"},
        rules=[fill],
        feature_defs={"water_level": MockFeatureDef("number")},
    )

    assert result.status == "success"
    assert [step.rule.code for step in result.path] == ["OP_FILL", "OP_FILL"]
    assert result.final_state["water_level"] == "40"


def test_forward_bfs_reports_no_solution_when_depth_limit_blocks_path():
    fill = MockRule(
        id=1,
        code="OP_FILL",
        duration_min=5,
        effects=[MockEffect("water_level", effect_type="increment", delta_value=10)],
    )

    result = forward_bfs_plan(
        current_state={"water_level": "0"},
        target_state={"water_level": "40"},
        rules=[fill],
        feature_defs={"water_level": MockFeatureDef("number")},
        limits=BfsLimits(max_depth=2, max_nodes=20),
    )

    assert result.status == "no_solution"
    assert result.error_code == "BFS_LIMIT_EXCEEDED"
