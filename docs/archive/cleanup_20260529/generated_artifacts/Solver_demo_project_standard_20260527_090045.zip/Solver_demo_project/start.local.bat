@echo off
set PYTHONIOENCODING=utf-8

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\scripts\launch_dev.ps1" -Mode local
if errorlevel 1 (
    echo [ERROR] Local launch failed.
    pause
    exit /b 1
)

pause
