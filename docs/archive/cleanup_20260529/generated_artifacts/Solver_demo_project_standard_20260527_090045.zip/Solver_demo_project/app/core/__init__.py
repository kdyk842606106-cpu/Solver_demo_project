# Core Business Logic
