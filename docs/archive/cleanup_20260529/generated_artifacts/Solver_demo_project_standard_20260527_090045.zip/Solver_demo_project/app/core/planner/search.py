"""
RAG (Resource-Aware Graph) construction module.

Planner uses forward BFS as its main state-space search strategy.  This module
loads states/rules, delegates path search to bfs.py, and converts the resulting
operation instances into the RAG contract consumed by Scheduler.
"""

from dataclasses import dataclass
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.planner.bfs import Transition, forward_bfs_plan
from app.core.planner.matcher import load_rules
from app.core.planner.state import StateDict, is_goal, load_state
from app.core.solver.rule_evaluator import RuleEvaluator
from app.db.models import (
    CandidatePlan,
    CandidatePlanStep,
    Machine,
    MachineState,
    StateFeatureDef,
)


@dataclass
class RAGNode:
    """Represents a node in the RAG."""

    id: int
    op_rule_id: int
    op_rule_code: str
    predecessors: list[int]


@dataclass
class RAG:
    """Represents a Resource-Aware Graph."""

    nodes: list[RAGNode]
    edges: list[tuple[int, int]]  # (from_id, to_id)


@dataclass
class PlanResult:
    """Result of RAG construction."""

    status: str  # "success" | "no_solution" | "error"
    rag: Optional[RAG] = None
    error_message: Optional[str] = None


async def _load_feature_defs(
    machine_type_id: int,
    session: AsyncSession,
) -> dict[str, StateFeatureDef]:
    """Load feature definitions for value_type based search guards."""
    result = await session.execute(
        select(StateFeatureDef).where(StateFeatureDef.machine_type_id == machine_type_id)
    )
    return {item.feature_key: item for item in result.scalars().all()}


async def build_rag(
    current_state_id: int,
    target_state_id: int,
    session: AsyncSession,
    current_state_override: dict | None = None,
    include_repair: bool = False,
) -> PlanResult:
    """
    Build a RAG from forward BFS state search.

    Args:
        current_state_id: ID of the current machine state.
        target_state_id: ID of the target machine state.
        session: SQLAlchemy async session.
        current_state_override: Optional feature injection used by Strategy B.
        include_repair: Whether repair rules can be expanded by BFS.
    """
    current_state_override = current_state_override or {}

    current_state = await load_state(current_state_id, session)
    if current_state is None:
        return PlanResult(
            status="error",
            error_message=f"Current state {current_state_id} not found",
        )
    current_state = {**current_state, **current_state_override}

    target_state = await load_state(target_state_id, session)
    if target_state is None:
        return PlanResult(
            status="error",
            error_message=f"Target state {target_state_id} not found",
        )

    if is_goal(current_state, target_state):
        return PlanResult(
            status="no_solution",
            error_message="Already at target state, no operations needed",
        )

    result = await session.execute(
        select(Machine)
        .join(MachineState)
        .where(MachineState.id == current_state_id)
    )
    machine = result.scalar_one_or_none()
    if machine is None:
        return PlanResult(
            status="error",
            error_message="Could not determine machine for state",
        )

    rules = await load_rules(machine.machine_type_id, session, include_repair=include_repair)
    if not rules:
        return PlanResult(
            status="no_solution",
            error_message="No operation rules found for machine type",
        )

    if include_repair and current_state_override:
        target_state = _with_repair_targets(current_state, target_state, rules)

    feature_defs = await _load_feature_defs(machine.machine_type_id, session)
    bfs_result = forward_bfs_plan(
        current_state=current_state,
        target_state=target_state,
        rules=rules,
        feature_defs=feature_defs,
    )
    if bfs_result.status != "success":
        return PlanResult(
            status=bfs_result.status,
            error_message=bfs_result.error_message,
        )

    rag = _path_to_rag(bfs_result.path, current_state)
    if has_cycle(rag.nodes, rag.edges):
        return PlanResult(
            status="error",
            error_message="Circular dependency detected in RAG",
        )

    return PlanResult(status="success", rag=rag)


def _with_repair_targets(
    current_state: StateDict,
    target_state: StateDict,
    rules: list,
) -> StateDict:
    """Add effects of currently applicable repair rules to the BFS goal."""
    evaluator = RuleEvaluator()
    adjusted_target = dict(target_state)
    for rule in rules:
        if not getattr(rule, "is_repair", False):
            continue
        if not evaluator.evaluate_preconditions(current_state, rule.preconditions):
            continue
        for effect in rule.effects:
            adjusted_target[effect.feature_key] = evaluator.apply_effect(
                current_state,
                effect,
            ).get(effect.feature_key, "")
    return adjusted_target


def _path_to_rag(path: list[Transition], initial_state: StateDict) -> RAG:
    """
    Convert a forward execution path into a compact dependency graph.

    Dependencies are inferred from feature reads/writes:
    - preconditions not satisfied by the initial state depend on the latest
      prior writer of that feature;
    - repeated writes to the same feature stay ordered.
    """
    evaluator = RuleEvaluator()
    latest_writer: dict[str, int] = {}
    nodes: list[RAGNode] = []
    edges: list[tuple[int, int]] = []

    for index, transition in enumerate(path, start=1):
        predecessors: set[int] = set()

        for precond in transition.rule.preconditions:
            current_initial_value = initial_state.get(precond.feature_key)
            before_value = transition.before_state.get(precond.feature_key)
            initial_satisfied = evaluator.evaluate_precondition(initial_state, precond)
            if (
                not initial_satisfied
                or before_value != current_initial_value
            ) and precond.feature_key in latest_writer:
                predecessors.add(latest_writer[precond.feature_key])

        for effect in transition.rule.effects:
            writer = latest_writer.get(effect.feature_key)
            if writer is not None:
                predecessors.add(writer)

        node = RAGNode(
            id=index,
            op_rule_id=transition.rule.id,
            op_rule_code=transition.rule.code,
            predecessors=sorted(predecessors),
        )
        nodes.append(node)
        for predecessor in node.predecessors:
            edge = (predecessor, node.id)
            if edge not in edges:
                edges.append(edge)

        for effect in transition.rule.effects:
            latest_writer[effect.feature_key] = node.id

    return RAG(nodes=nodes, edges=edges)


def has_cycle(nodes: list[RAGNode], edges: list[tuple[int, int]]) -> bool:
    """
    Check if the RAG has a cycle using DFS.

    Args:
        nodes: List of RAG nodes
        edges: List of (from, to) edges

    Returns:
        True if a cycle exists
    """
    adj: dict[int, list[int]] = {n.id: [] for n in nodes}
    for from_id, to_id in edges:
        adj[from_id].append(to_id)

    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n.id: WHITE for n in nodes}

    def dfs(node_id: int) -> bool:
        color[node_id] = GRAY
        for neighbor in adj.get(node_id, []):
            if color[neighbor] == GRAY:
                return True
            if color[neighbor] == WHITE:
                if dfs(neighbor):
                    return True
        color[node_id] = BLACK
        return False

    for node in nodes:
        if color[node.id] == WHITE:
            if dfs(node.id):
                return True

    return False


async def save_candidate_plan(
    rag: RAG,
    solve_request_id: int,
    session: AsyncSession,
    version: int = 1,
    parent_plan_id: int | None = None,
    replan_reason: str | None = None,
) -> int:
    """
    Save a RAG to the database as a candidate plan.

    Args:
        rag: RAG to save
        solve_request_id: ID of the solve request
        session: SQLAlchemy async session
        version: Plan version number (default 1)
        parent_plan_id: Parent plan ID for version chain (default None)
        replan_reason: Reason for replan (default None)

    Returns:
        ID of the created candidate_plan
    """
    candidate_plan = CandidatePlan(
        solve_request_id=solve_request_id,
        total_steps=len(rag.nodes),
        search_method="forward_bfs",
        version=version,
        parent_plan_id=parent_plan_id,
        replan_reason=replan_reason,
    )
    session.add(candidate_plan)
    await session.flush()

    for node in rag.nodes:
        step = CandidatePlanStep(
            candidate_plan_id=candidate_plan.id,
            step_order=node.id,
            op_rule_id=node.op_rule_id,
            predecessor_ids=node.predecessors,
        )
        session.add(step)

    return candidate_plan.id


def format_rag(rag: RAG) -> str:
    """
    Format RAG as a human-readable string.

    Args:
        rag: RAG to format

    Returns:
        Human-readable string representation
    """
    lines = ["RAG Structure:"]
    lines.append("-" * 40)

    for node in rag.nodes:
        preds = ", ".join(str(p) for p in node.predecessors) or "none"
        lines.append(f"  Node {node.id}: {node.op_rule_code} (predecessors: {preds})")

    if rag.edges:
        lines.append("")
        lines.append("Dependencies:")
        for from_id, to_id in rag.edges:
            lines.append(f"  {from_id} -> {to_id}")

    parallel_groups = find_parallel_groups(rag)
    if parallel_groups:
        lines.append("")
        lines.append("Parallel opportunities:")
        for group in parallel_groups:
            lines.append(f"  Nodes {group} can run in parallel")

    return "\n".join(lines)


def find_parallel_groups(rag: RAG) -> list[list[int]]:
    """
    Find groups of nodes that can run in parallel.

    Two nodes can run in parallel if they have the same predecessors
    (or both have no predecessors).
    """
    pred_groups: dict[frozenset[int], list[int]] = {}

    for node in rag.nodes:
        pred_key = frozenset(node.predecessors)
        if pred_key not in pred_groups:
            pred_groups[pred_key] = []
        pred_groups[pred_key].append(node.id)

    parallel_groups = []
    for group in pred_groups.values():
        if len(group) > 1:
            parallel_groups.append(sorted(group))

    return parallel_groups
