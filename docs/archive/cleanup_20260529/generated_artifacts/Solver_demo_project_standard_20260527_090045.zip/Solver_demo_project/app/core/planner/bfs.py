"""
Forward BFS state-space search for planner rule selection.

The search expands executable operation rules from the current state and stops
when the original state delta has been satisfied.  Rule checks and effects stay
behind RuleEvaluator so operator/effect registries remain the single entrypoint.
"""

from collections import deque
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from app.core.planner.state import StateDict, compute_state_delta, freeze
from app.core.solver.rule_evaluator import RuleEvaluator
from app.db.models import OpRule, StateFeatureDef


BFS_LIMIT_EXCEEDED = "BFS_LIMIT_EXCEEDED"
BFS_NO_SOLUTION = "BFS_NO_SOLUTION"
BFS_INVALID_NUMERIC_VALUE = "BFS_INVALID_NUMERIC_VALUE"


@dataclass(frozen=True)
class BfsLimits:
    """Safety limits for forward search."""

    max_depth: int = 50
    max_nodes: int = 2000


@dataclass
class Transition:
    """One instantiated operation rule in a discovered search path."""

    rule: OpRule
    before_state: StateDict
    after_state: StateDict


@dataclass
class SearchNode:
    """A BFS frontier item."""

    state: StateDict
    path: list[Transition] = field(default_factory=list)

    @property
    def depth(self) -> int:
        return len(self.path)


@dataclass
class BfsPlanResult:
    """Result of forward BFS planning."""

    status: str  # success | no_solution | error
    path: list[Transition] = field(default_factory=list)
    final_state: StateDict | None = None
    error_code: str | None = None
    error_message: str | None = None


def forward_bfs_plan(
    current_state: StateDict,
    target_state: StateDict,
    rules: list[OpRule],
    feature_defs: dict[str, StateFeatureDef],
    limits: BfsLimits | None = None,
) -> BfsPlanResult:
    """
    Search forward from current_state until all initially different target
    features are satisfied.

    The goal is intentionally the initial delta subset, not every target feature.
    This preserves existing planner semantics where temporary support features
    may move away from their original value while enabling a target-changing op.
    """
    limits = limits or BfsLimits()
    goal_state = _goal_state(current_state, target_state, feature_defs)
    if not goal_state:
        return BfsPlanResult(status="success", final_state=dict(current_state))

    bounds_result = _build_numeric_bounds(
        current_state=current_state,
        target_state=target_state,
        goal_state=goal_state,
        rules=rules,
        feature_defs=feature_defs,
    )
    if isinstance(bounds_result, BfsPlanResult):
        return bounds_result
    numeric_bounds = bounds_result

    evaluator = RuleEvaluator()
    ordered_rules = sorted(rules, key=lambda rule: (rule.duration_min, rule.id or 0))
    queue: deque[SearchNode] = deque([SearchNode(state=dict(current_state))])
    visited = {freeze(current_state)}
    expanded_nodes = 0
    limit_reached = False

    while queue:
        node = queue.popleft()
        expanded_nodes += 1
        if expanded_nodes > limits.max_nodes:
            limit_reached = True
            break

        if _matches_goal(node.state, goal_state, feature_defs):
            return BfsPlanResult(
                status="success",
                path=node.path,
                final_state=dict(node.state),
            )

        if node.depth >= limits.max_depth:
            limit_reached = True
            continue

        for rule in ordered_rules:
            if not evaluator.evaluate_preconditions(node.state, rule.preconditions):
                continue

            next_state = evaluator.apply_effects(node.state, rule.effects)
            if freeze(next_state) == freeze(node.state):
                continue
            if not _within_numeric_bounds(next_state, numeric_bounds):
                continue

            state_key = freeze(next_state)
            if state_key in visited:
                continue

            visited.add(state_key)
            queue.append(
                SearchNode(
                    state=next_state,
                    path=[
                        *node.path,
                        Transition(
                            rule=rule,
                            before_state=dict(node.state),
                            after_state=dict(next_state),
                        ),
                    ],
                )
            )

    if limit_reached:
        return BfsPlanResult(
            status="no_solution",
            error_code=BFS_LIMIT_EXCEEDED,
            error_message=(
                f"Forward BFS exceeded limits: max_depth={limits.max_depth}, "
                f"max_nodes={limits.max_nodes}"
            ),
        )

    return BfsPlanResult(
        status="no_solution",
        error_code=BFS_NO_SOLUTION,
        error_message="No forward BFS path can reach the target state",
    )


def _goal_state(
    current_state: StateDict,
    target_state: StateDict,
    feature_defs: dict[str, StateFeatureDef],
) -> StateDict:
    goal: StateDict = {}
    for key, (_, target_value) in compute_state_delta(current_state, target_state).items():
        current_value = current_state.get(key)
        if not _values_equal(current_value, target_value, feature_defs.get(key)):
            goal[key] = target_value
    return goal


def _matches_goal(
    state: StateDict,
    goal_state: StateDict,
    feature_defs: dict[str, StateFeatureDef],
) -> bool:
    return all(
        _values_equal(state.get(key), target_value, feature_defs.get(key))
        for key, target_value in goal_state.items()
    )


def _values_equal(
    left: str | None,
    right: str | None,
    feature_def: StateFeatureDef | None,
) -> bool:
    if feature_def is not None and feature_def.value_type == "number":
        try:
            return _parse_decimal(left) == _parse_decimal(right)
        except ValueError:
            return False
    return left == right


def _build_numeric_bounds(
    current_state: StateDict,
    target_state: StateDict,
    goal_state: StateDict,
    rules: list[OpRule],
    feature_defs: dict[str, StateFeatureDef],
) -> dict[str, tuple[Decimal, Decimal]] | BfsPlanResult:
    bounds: dict[str, list[Decimal]] = {}
    numeric_keys = {
        key
        for key, feature_def in feature_defs.items()
        if feature_def.value_type == "number"
    }

    for key in numeric_keys:
        for raw_value in (current_state.get(key), target_state.get(key), goal_state.get(key)):
            if raw_value is None:
                continue
            try:
                bounds.setdefault(key, []).append(_parse_decimal(raw_value))
            except ValueError as exc:
                return BfsPlanResult(
                    status="error",
                    error_code=BFS_INVALID_NUMERIC_VALUE,
                    error_message=str(exc),
                )

    for rule in rules:
        for precond in rule.preconditions:
            if precond.feature_key not in numeric_keys:
                continue
            try:
                bounds.setdefault(precond.feature_key, []).append(
                    _parse_decimal(precond.feature_value)
                )
            except ValueError:
                continue
        for effect in rule.effects:
            if effect.feature_key not in numeric_keys:
                continue
            if getattr(effect, "effect_type", "set") == "set":
                try:
                    bounds.setdefault(effect.feature_key, []).append(
                        _parse_decimal(getattr(effect, "new_value", None))
                    )
                except ValueError:
                    continue

    return {
        key: (min(values), max(values))
        for key, values in bounds.items()
        if values
    }


def _within_numeric_bounds(
    state: StateDict,
    numeric_bounds: dict[str, tuple[Decimal, Decimal]],
) -> bool:
    for key, (lower, upper) in numeric_bounds.items():
        if key not in state:
            continue
        try:
            value = _parse_decimal(state.get(key))
        except ValueError:
            return False
        if value < lower or value > upper:
            return False
    return True


def _parse_decimal(value: object) -> Decimal:
    if value is None or value == "":
        return Decimal("0")
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"Invalid numeric value: {value}") from exc
