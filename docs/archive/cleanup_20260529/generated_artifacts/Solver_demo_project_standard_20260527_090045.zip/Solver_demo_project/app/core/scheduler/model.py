"""
CP-SAT constraint model builder.

Translates the RAG structure and resource constraints into a CP-SAT model:
- Task interval variables (start, end, interval)
- Precedence constraints from RAG edges
- Cumulative resource capacity constraints
- Minimize makespan objective
"""

from dataclasses import dataclass
from typing import Any

from ortools.sat.python import cp_model

from app.core.scheduler.loader import RagData, ResourceData, get_resource_capacity


@dataclass
class TaskVar:
    """CP-SAT variables for a single task."""
    step_order: int
    start: Any  # cp_model.IntVar
    end: Any    # cp_model.IntVar
    interval: Any  # cp_model.IntervalVar
    duration: int
    resource_type: str


def step_resource_requirements(step: Any) -> dict[str, int]:
    """Return normalized required resource quantities for one step.

    `resource_reqs` is the canonical multi-resource contract.  The legacy
    `resource_type/resource_qty` pair is retained as a fallback so older tests
    and persisted rows still schedule the same way.
    """
    requirements: dict[str, int] = {}

    for req in getattr(step, "resource_reqs", []) or []:
        resource_type = req.get("resource_type") or "NONE"
        if resource_type == "NONE":
            continue

        quantity = int(req.get("quantity") or 1)
        if quantity <= 0:
            quantity = 1
        requirements[resource_type] = requirements.get(resource_type, 0) + quantity

    if not requirements:
        resource_type = getattr(step, "resource_type", "NONE")
        if resource_type != "NONE":
            quantity = getattr(step, "resource_qty", 0) or 1
            requirements[resource_type] = max(int(quantity), 1)

    return requirements


@dataclass
class ScheduleModel:
    """Packaged CP-SAT model ready for solving."""
    model: cp_model.CpModel
    task_vars: dict[int, TaskVar]  # step_order -> TaskVar
    makespan: Any  # cp_model.IntVar
    horizon: int


def build_model(
    rag_data: RagData,
    resources: list[ResourceData],
    objectives: list[dict] | None = None,
) -> ScheduleModel:
    """
    Build a CP-SAT model from RAG data and resources.

    Args:
        rag_data: RAG structure with step durations and resource types
        resources: Available resource instances
        objectives: List of objective dicts, e.g. [{"type": "minimize_makespan", "weight": 1.0}]

    Returns:
        ScheduleModel ready for solving
    """
    model = cp_model.CpModel()

    horizon = sum(s.duration_min for s in rag_data.steps)
    max_not_before = max(
        (s.not_before for s in rag_data.steps if s.not_before is not None),
        default=0,
    )
    if max_not_before > 0:
        horizon = max_not_before + horizon

    task_vars: dict[int, TaskVar] = {}

    for step in rag_data.steps:
        so = step.step_order
        start = model.new_int_var(0, horizon, f"start_{so}")
        end = model.new_int_var(0, horizon, f"end_{so}")
        interval = model.new_interval_var(
            start, step.duration_min, end, f"interval_{so}"
        )

        task_vars[so] = TaskVar(
            step_order=so,
            start=start,
            end=end,
            interval=interval,
            duration=step.duration_min,
            resource_type=step.resource_type,
        )

    for pred_so, succ_so in rag_data.edges:
        if pred_so in task_vars and succ_so in task_vars:
            model.add(task_vars[succ_so].start >= task_vars[pred_so].end)

    requirements_by_step = {
        s.step_order: step_resource_requirements(s)
        for s in rag_data.steps
    }
    resource_type_set = sorted({
        resource_type
        for requirements in requirements_by_step.values()
        for resource_type in requirements
    })

    for res_type in resource_type_set:
        capacity = get_resource_capacity(resources, res_type)
        if capacity <= 0:
            capacity = 1

        intervals = []
        demands = []

        for step in rag_data.steps:
            demand = requirements_by_step[step.step_order].get(res_type)
            if demand is not None:
                tv = task_vars[step.step_order]
                intervals.append(tv.interval)
                demands.append(demand)

        if intervals:
            model.add_cumulative(intervals, demands, capacity)

    makespan = model.new_int_var(0, horizon, "makespan")
    model.add_max_equality(makespan, [tv.end for tv in task_vars.values()])

    for step in rag_data.steps:
        if step.not_before is not None:
            model.add(task_vars[step.step_order].start >= step.not_before)

    schedule_model = ScheduleModel(
        model=model,
        task_vars=task_vars,
        makespan=makespan,
        horizon=horizon,
    )

    if objectives is None:
        objectives = [{"type": "minimize_makespan", "weight": 1.0}]
    from app.core.solver.objectives import ObjectiveRegistry
    ObjectiveRegistry.apply_all(objectives, schedule_model)

    return schedule_model
