# Planner 模块协议

路径：`app/core/planner/`

Planner 的职责是从当前状态出发，在规则库中正向搜索可执行工序，直到满足目标状态中相对当前状态发生变化的目标特征，然后将搜索路径转换为 Scheduler 可消费的 RAG。

---

## 核心入口

### `build_rag(current_state_id, target_state_id, session, current_state_override=None, include_repair=False) -> PlanResult`

返回值结构：

```python
PlanResult(
    status="success" | "no_solution" | "error",
    rag=RAG(...) | None,
    error_message=str | None,
)
```

其中 `RAG` 结构为：

```python
RAG(
    nodes=[
        RAGNode(
            id=1,
            op_rule_id=3,
            op_rule_code="OP_WARMUP",
            predecessors=[],
        )
    ],
    edges=[(1, 2)],
)
```

### `save_candidate_plan(rag, solve_request_id, session) -> int`

将 RAG 落库到：

- `candidate_plan`
- `candidate_plan_step`

`search_method` 当前写入 `forward_bfs`。

---

## 当前主策略：正向 BFS

Planner 不再使用旧的「状态差 delta 匹配 + 逆向依赖补齐」作为主流程。当前流程是：

1. 加载 `current_state` 与 `target_state`。
2. 如有 `current_state_override`，先注入到当前状态副本，不修改数据库原始状态。
3. 计算初始 delta，得到目标特征集合。
4. 加载当前机型的 active `OpRule`，`include_repair=True` 时包含 repair rule。
5. 从 current_state 开始做正向 BFS：
   - 只展开当前状态下 precondition 满足的规则；
   - 所有 precondition 判断通过 `RuleEvaluator.evaluate_preconditions()`；
   - 所有 effect 应用通过 `RuleEvaluator.apply_effects()`；
   - 使用 `freeze(state)` 做 visited 去重；
   - 使用 `max_depth` / `max_nodes` 做安全上限；
   - 数值型 increment/decrement 规则作为普通规则自然重复实例化。
6. 搜索成功后，将 transition path 转换为 RAG。
7. RAG 经过 cycle detection 后返回。

注意：BFS 的 goal predicate 使用「初始 delta 目标特征」，而不是要求最终状态完全等于 target_state 的所有特征。这保留了既有语义：某些临时支撑特征可以为了满足前置条件而变化，但不作为本次目标特征。

---

## numeric 收敛说明

`numeric.py` 不再作为 `build_rag()` 主流程的专用分流。

数值型能力现在由统一 BFS 表达：

- `increment` / `decrement` 通过 `RuleEvaluator` 应用；
- 同一 `OpRule` 的多次执行以多个 transition / RAGNode 实例表达；
- 隐式 numeric precondition 通过正向状态推进自然满足；
- 数值安全边界由 BFS 根据 current/target/precondition 值构造，避免无限递增或递减。

`numeric.py` 可暂时保留为历史兼容工具，但不再参与 Planner 主干。

---

## RAG 依赖生成

BFS 先得到一条有序 transition path，再转换为 RAG。

依赖压缩规则：

- 如果某一步 precondition 在初始状态不满足，则依赖该 feature 的最近 prior writer。
- 如果某一步读取的 feature 已被之前步骤改写，则依赖最近 prior writer。
- 如果某一步写入某 feature，且之前已有步骤写过同一 feature，则依赖最近 prior writer，保证重复数值步骤顺序正确。
- 其余无依赖步骤可自然并行。

这保证：

- 重复 `op_rule_id` 能落为多个 `CandidatePlanStep`；
- 数值递增链不会被 Scheduler 并行化；
- 无依赖分支仍能形成 parallel opportunities。

---

## repair / blockage 语义

- Strategy B / AB 通过 `current_state_override` 注入 `blockage_reason`。
- `include_repair=True` 时，repair rule 会进入 BFS 候选规则集。
- 若 repair rule 在注入后的当前状态下可执行，其 effects 会被加入 BFS goal，避免 BFS 在普通目标满足后提前停止而遗漏 repair step。

RAGBuilder 仍不理解“阻塞”业务概念，只处理通用状态特征和规则；阻塞语义来自外部注入的状态特征。

---

## 输出契约

Planner 对 Scheduler 的共享数据契约仍是 `candidate_plan_step`：

| 字段 | 说明 |
|------|------|
| `step_order` | RAGNode.id，从 1 开始 |
| `op_rule_id` | 关联工序规则，允许重复 |
| `predecessor_ids` | 本步骤前驱步骤的 `step_order` 列表 |

只要图无环，Scheduler 可根据 `predecessor_ids` 构建 precedence 约束。

---

## 失败语义

| 场景 | 返回 |
|------|------|
| 当前状态已满足目标 delta | `status="no_solution"` |
| 没有规则 | `status="no_solution"` |
| BFS 队列耗尽，找不到路径 | `status="no_solution"` |
| BFS 达到 `max_depth` / `max_nodes` | `status="no_solution"` |
| 当前状态或目标状态不存在 | `status="error"` |
| 无法确定机台/机型 | `status="error"` |
| RAG cycle detection 失败 | `status="error"` |

API 层继续将 Planner 的 `no_solution` 映射为 `NO_SOLUTION`。

