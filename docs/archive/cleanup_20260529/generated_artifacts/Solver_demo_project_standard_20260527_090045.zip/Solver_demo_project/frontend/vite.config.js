import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://172.26.16.1:8000',
        changeOrigin: true,
      },
      '/health': {
        target: 'http://172.26.16.1:8000',
        changeOrigin: true,
      },
    },
  },
})
